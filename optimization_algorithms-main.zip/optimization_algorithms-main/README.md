# Optimization Algorithms Course - Coding Assignments

This repository contains the assignments and public testing
code. Students should not edit this.

The repository should usually be used as submodule of the student's
workspace repository: Please fork the oa-workspace, copy a specific
assignment folder to your workspace, and work there.
