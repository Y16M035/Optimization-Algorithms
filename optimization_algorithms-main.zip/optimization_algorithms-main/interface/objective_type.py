class OT():
    none = 0
    f = 1
    sos = 2
    ineq = 3
    eq = 4
